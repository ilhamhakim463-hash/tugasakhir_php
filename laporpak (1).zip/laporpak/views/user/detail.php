<?php $user = Auth::user(); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Aduan - LAPORPAK</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?= BASE_URL ?>?page=user-dashboard"><i class="fas fa-landmark"></i> LAPORPAK</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>?page=user-dashboard">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>?page=user-create">Buat Aduan</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>?page=user-riwayat">Riwayat</a></li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user"></i> <?= htmlspecialchars($user['nama']) ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="<?= BASE_URL ?>?page=logout"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <a href="<?= BASE_URL ?>?page=user-dashboard" class="btn btn-secondary mb-3"><i class="fas fa-arrow-left"></i> Kembali</a>

        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Detail Aduan</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-8">
                        <h4><?= htmlspecialchars($aduan['judul']) ?></h4>
                        <p class="text-muted">
                            <i class="fas fa-calendar"></i> <?= date('d/m/Y H:i', strtotime($aduan['created_at'])) ?>
                            <span class="ms-3"><i class="fas fa-folder"></i> <?= htmlspecialchars($aduan['nama_kategori']) ?></span>
                        </p>
                        <?php if ($aduan['lokasi']): ?>
                            <p><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($aduan['lokasi']) ?></p>
                        <?php endif; ?>
                        <hr>
                        <p><?= nl2br(htmlspecialchars($aduan['isi'])) ?></p>
                        <?php if ($aduan['foto']): ?>
                            <img src="<?= UPLOAD_URL . $aduan['foto'] ?>" class="img-fluid rounded mt-3" alt="Foto Aduan">
                        <?php endif; ?>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <h6>Status</h6>
                                <?php
                                $badge_class = 'secondary';
                                if ($aduan['status'] === STATUS_PENDING) $badge_class = 'warning';
                                if ($aduan['status'] === STATUS_PROSES) $badge_class = 'info';
                                if ($aduan['status'] === STATUS_SELESAI) $badge_class = 'success';
                                ?>
                                <span class="badge bg-<?= $badge_class ?> fs-6"><?= ucfirst($aduan['status']) ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php if (!empty($tanggapan_list)): ?>
            <div class="card mt-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Tanggapan</h5>
                </div>
                <div class="card-body">
                    <?php foreach ($tanggapan_list as $tanggapan): ?>
                        <div class="alert alert-info">
                            <strong><?= htmlspecialchars($tanggapan['admin_nama']) ?></strong>
                            <small class="text-muted float-end"><?= date('d/m/Y H:i', strtotime($tanggapan['created_at'])) ?></small>
                            <p class="mt-2 mb-0"><?= nl2br(htmlspecialchars($tanggapan['isi'])) ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
