<?php $user = Auth::user(); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Aduan - LAPORPAK</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?= BASE_URL ?>?page=user-dashboard"><i class="fas fa-landmark"></i> LAPORPAK</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>?page=user-dashboard">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>?page=user-create">Buat Aduan</a></li>
                    <li class="nav-item"><a class="nav-link active" href="<?= BASE_URL ?>?page=user-riwayat">Riwayat</a></li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user"></i> <?= htmlspecialchars($user['nama']) ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="<?= BASE_URL ?>?page=logout"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="card">
            <div class="card-header bg-white">
                <h5 class="mb-0">Riwayat Semua Aduan</h5>
            </div>
            <div class="card-body">
                <?php if (empty($aduan_list)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                        <p class="text-muted">Belum ada riwayat aduan</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Judul</th>
                                    <th>Kategori</th>
                                    <th>Status</th>
                                    <th>Tanggal</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; foreach ($aduan_list as $aduan): ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= htmlspecialchars($aduan['judul']) ?></td>
                                    <td><span class="badge bg-secondary"><?= htmlspecialchars($aduan['nama_kategori']) ?></span></td>
                                    <td>
                                        <?php
                                        $badge_class = 'secondary';
                                        if ($aduan['status'] === STATUS_PENDING) $badge_class = 'warning';
                                        if ($aduan['status'] === STATUS_PROSES) $badge_class = 'info';
                                        if ($aduan['status'] === STATUS_SELESAI) $badge_class = 'success';
                                        ?>
                                        <span class="badge bg-<?= $badge_class ?>"><?= ucfirst($aduan['status']) ?></span>
                                    </td>
                                    <td><?= date('d/m/Y', strtotime($aduan['created_at'])) ?></td>
                                    <td>
                                        <a href="<?= BASE_URL ?>?page=user-detail&id=<?= $aduan['id'] ?>" class="btn btn-sm btn-primary">
                                            <i class="fas fa-eye"></i> Detail
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
