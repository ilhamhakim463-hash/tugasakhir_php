<?php $user = Auth::user(); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - LAPORPAK</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-light">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?= BASE_URL ?>?page=admin-dashboard">
                <i class="fas fa-landmark"></i> LAPORPAK Admin
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="<?= BASE_URL ?>?page=admin-dashboard">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= BASE_URL ?>?page=admin-aduan">Kelola Aduan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= BASE_URL ?>?page=admin-kategori">Kategori</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= BASE_URL ?>?page=admin-users">Users</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-shield"></i> <?= htmlspecialchars($user['nama']) ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="<?= BASE_URL ?>?page=logout"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid mt-4">
        <h2 class="mb-4">Dashboard Admin</h2>

        <!-- Stats Cards -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card text-white bg-primary">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white-50">Total Aduan</h6>
                                <h2 class="mb-0"><?= $stats['total'] ?></h2>
                            </div>
                            <i class="fas fa-folder fa-3x opacity-25"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-warning">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white-50">Pending</h6>
                                <h2 class="mb-0"><?= $stats['pending'] ?></h2>
                            </div>
                            <i class="fas fa-clock fa-3x opacity-25"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-info">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white-50">Diproses</h6>
                                <h2 class="mb-0"><?= $stats['proses'] ?></h2>
                            </div>
                            <i class="fas fa-spinner fa-3x opacity-25"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-success">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white-50">Selesai</h6>
                                <h2 class="mb-0"><?= $stats['selesai'] ?></h2>
                            </div>
                            <i class="fas fa-check-circle fa-3x opacity-25"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <h6 class="text-muted">Aduan Hari Ini</h6>
                        <h3><?= $stats['hari_ini'] ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <h6 class="text-muted">Total User</h6>
                        <h3><?= $stats['total_user'] ?></h3>
                    </div>
                </div>
            </div>
        </div>

        <!-- Charts -->
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">Aduan per Kategori</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="chartKategori"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">Status Aduan</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="chartStatus"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Aduan Terbaru -->
        <div class="card">
            <div class="card-header bg-white">
                <h5 class="mb-0">Aduan Terbaru</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Pelapor</th>
                                <th>Judul</th>
                                <th>Kategori</th>
                                <th>Status</th>
                                <th>Tanggal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($aduan_terbaru as $aduan): ?>
                            <tr>
                                <td><?= htmlspecialchars($aduan['user_nama']) ?></td>
                                <td><?= htmlspecialchars($aduan['judul']) ?></td>
                                <td><span class="badge bg-secondary"><?= htmlspecialchars($aduan['nama_kategori']) ?></span></td>
                                <td>
                                    <?php
                                    $badge_class = 'secondary';
                                    if ($aduan['status'] === STATUS_PENDING) $badge_class = 'warning';
                                    if ($aduan['status'] === STATUS_PROSES) $badge_class = 'info';
                                    if ($aduan['status'] === STATUS_SELESAI) $badge_class = 'success';
                                    ?>
                                    <span class="badge bg-<?= $badge_class ?>"><?= ucfirst($aduan['status']) ?></span>
                                </td>
                                <td><?= date('d/m/Y H:i', strtotime($aduan['created_at'])) ?></td>
                                <td>
                                    <a href="<?= BASE_URL ?>?page=admin-aduan-detail&id=<?= $aduan['id'] ?>" class="btn btn-sm btn-primary">
                                        <i class="fas fa-eye"></i> Detail
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Chart Kategori
        const ctxKategori = document.getElementById('chartKategori').getContext('2d');
        new Chart(ctxKategori, {
            type: 'pie',
            data: {
                labels: [<?php echo implode(',', array_map(fn($k) => '"' . $k['nama_kategori'] . '"', $stats_kategori)); ?>],
                datasets: [{
                    data: [<?php echo implode(',', array_map(fn($k) => $k['jumlah'], $stats_kategori)); ?>],
                    backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40']
                }]
            }
        });

        // Chart Status
        const ctxStatus = document.getElementById('chartStatus').getContext('2d');
        new Chart(ctxStatus, {
            type: 'doughnut',
            data: {
                labels: ['Pending', 'Proses', 'Selesai'],
                datasets: [{
                    data: [<?= $stats['pending'] ?>, <?= $stats['proses'] ?>, <?= $stats['selesai'] ?>],
                    backgroundColor: ['#FFC107', '#17A2B8', '#28A745']
                }]
            }
        });
    </script>
</body>
</html>
