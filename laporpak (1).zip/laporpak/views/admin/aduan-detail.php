<?php $user_admin = Auth::user(); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Aduan - LAPORPAK Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?= BASE_URL ?>?page=admin-dashboard"><i class="fas fa-landmark"></i> LAPORPAK Admin</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>?page=admin-dashboard">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link active" href="<?= BASE_URL ?>?page=admin-aduan">Kelola Aduan</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>?page=admin-kategori">Kategori</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>?page=admin-users">Users</a></li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                            <i class="fas fa-user-shield"></i> <?= htmlspecialchars($user_admin['nama']) ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="<?= BASE_URL ?>?page=logout"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <a href="<?= BASE_URL ?>?page=admin-aduan" class="btn btn-secondary mb-3"><i class="fas fa-arrow-left"></i> Kembali</a>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?= $_SESSION['success'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-8">
                <div class="card mb-4">
                    <div class="card-header bg-dark text-white">
                        <h5 class="mb-0">Detail Aduan</h5>
                    </div>
                    <div class="card-body">
                        <h4><?= htmlspecialchars($aduan['judul']) ?></h4>
                        <p class="text-muted">
                            <i class="fas fa-user"></i> <?= htmlspecialchars($aduan['user_nama']) ?> (<?= htmlspecialchars($aduan['user_email']) ?>)<br>
                            <i class="fas fa-calendar"></i> <?= date('d/m/Y H:i', strtotime($aduan['created_at'])) ?><br>
                            <i class="fas fa-folder"></i> <?= htmlspecialchars($aduan['nama_kategori']) ?>
                        </p>
                        <?php if ($aduan['lokasi']): ?>
                            <p><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($aduan['lokasi']) ?></p>
                        <?php endif; ?>
                        <hr>
                        <p><?= nl2br(htmlspecialchars($aduan['isi'])) ?></p>
                        <?php if ($aduan['foto']): ?>
                            <img src="<?= UPLOAD_URL . $aduan['foto'] ?>" class="img-fluid rounded mt-3" alt="Foto Aduan">
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Form Tanggapan -->
                <div class="card">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">Beri Tanggapan</h5>
                    </div>
                    <div class="card-body">
                        <form action="<?= BASE_URL ?>?page=admin-tanggapi" method="POST">
                            <?= csrfField() ?>
                            <input type="hidden" name="aduan_id" value="<?= $aduan['id'] ?>">
                            <div class="mb-3">
                                <textarea class="form-control" name="isi" rows="4" placeholder="Tulis tanggapan..." required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-paper-plane"></i> Kirim Tanggapan
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Riwayat Tanggapan -->
                <?php if (!empty($tanggapan_list)): ?>
                    <div class="card mt-4">
                        <div class="card-header bg-white">
                            <h5 class="mb-0">Riwayat Tanggapan</h5>
                        </div>
                        <div class="card-body">
                            <?php foreach ($tanggapan_list as $tanggapan): ?>
                                <div class="alert alert-info">
                                    <strong><?= htmlspecialchars($tanggapan['admin_nama']) ?></strong>
                                    <small class="text-muted float-end"><?= date('d/m/Y H:i', strtotime($tanggapan['created_at'])) ?></small>
                                    <p class="mt-2 mb-0"><?= nl2br(htmlspecialchars($tanggapan['isi'])) ?></p>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <div class="col-md-4">
                <!-- Update Status -->
                <div class="card mb-3">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">Ubah Status</h5>
                    </div>
                    <div class="card-body">
                        <form action="<?= BASE_URL ?>?page=admin-update-status" method="POST">
                            <?= csrfField() ?>
                            <input type="hidden" name="id" value="<?= $aduan['id'] ?>">
                            <div class="mb-3">
                                <label class="form-label">Status Saat Ini:</label>
                                <?php
                                $badge_class = 'secondary';
                                if ($aduan['status'] === STATUS_PENDING) $badge_class = 'warning';
                                if ($aduan['status'] === STATUS_PROSES) $badge_class = 'info';
                                if ($aduan['status'] === STATUS_SELESAI) $badge_class = 'success';
                                ?>
                                <div><span class="badge bg-<?= $badge_class ?> fs-6"><?= ucfirst($aduan['status']) ?></span></div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Ubah ke:</label>
                                <select class="form-select" name="status" required>
                                    <option value="pending" <?= $aduan['status'] === STATUS_PENDING ? 'selected' : '' ?>>Pending</option>
                                    <option value="proses" <?= $aduan['status'] === STATUS_PROSES ? 'selected' : '' ?>>Proses</option>
                                    <option value="selesai" <?= $aduan['status'] === STATUS_SELESAI ? 'selected' : '' ?>>Selesai</option>
                                    <option value="ditolak" <?= $aduan['status'] === STATUS_DITOLAK ? 'selected' : '' ?>>Ditolak</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-save"></i> Update Status
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
