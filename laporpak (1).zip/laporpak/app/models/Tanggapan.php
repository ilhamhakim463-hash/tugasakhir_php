<?php

class Tanggapan {
    private $conn;
    private $table_name = "tanggapan";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create($data) {
        $query = "INSERT INTO " . $this->table_name . " 
                  (aduan_id, admin_id, isi) 
                  VALUES (:aduan_id, :admin_id, :isi)";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(':aduan_id', $data['aduan_id']);
        $stmt->bindParam(':admin_id', $data['admin_id']);
        $stmt->bindParam(':isi', $data['isi']);
        
        return $stmt->execute();
    }

    public function getByAduanId($aduan_id) {
        $query = "SELECT t.*, u.nama as admin_nama 
                  FROM " . $this->table_name . " t
                  LEFT JOIN users u ON t.admin_id = u.id
                  WHERE t.aduan_id = :aduan_id
                  ORDER BY t.created_at ASC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':aduan_id', $aduan_id);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function delete($id) {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }
}

?>
