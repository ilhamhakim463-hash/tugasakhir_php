<?php

class Aduan {
    private $conn;
    private $table_name = "aduan";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create($data) {
        $query = "INSERT INTO " . $this->table_name . " 
                  (user_id, kategori_id, judul, isi, lokasi, foto, status) 
                  VALUES (:user_id, :kategori_id, :judul, :isi, :lokasi, :foto, :status)";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(':user_id', $data['user_id']);
        $stmt->bindParam(':kategori_id', $data['kategori_id']);
        $stmt->bindParam(':judul', $data['judul']);
        $stmt->bindParam(':isi', $data['isi']);
        $stmt->bindParam(':lokasi', $data['lokasi']);
        $foto = $data['foto'] ?? null;
        $stmt->bindParam(':foto', $foto);
        $status = $data['status'] ?? STATUS_PENDING;
        $stmt->bindParam(':status', $status);
        
        return $stmt->execute();
    }

    public function getAll($limit = null) {
        $query = "SELECT a.*, u.nama as user_nama, k.nama_kategori 
                  FROM " . $this->table_name . " a
                  LEFT JOIN users u ON a.user_id = u.id
                  LEFT JOIN kategori k ON a.kategori_id = k.id
                  ORDER BY a.created_at DESC";
        
        if ($limit) {
            $query .= " LIMIT " . intval($limit);
        }
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getByUserId($user_id) {
        $query = "SELECT a.*, k.nama_kategori 
                  FROM " . $this->table_name . " a
                  LEFT JOIN kategori k ON a.kategori_id = k.id
                  WHERE a.user_id = :user_id
                  ORDER BY a.created_at DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($id) {
        $query = "SELECT a.*, u.nama as user_nama, u.email as user_email, k.nama_kategori 
                  FROM " . $this->table_name . " a
                  LEFT JOIN users u ON a.user_id = u.id
                  LEFT JOIN kategori k ON a.kategori_id = k.id
                  WHERE a.id = :id LIMIT 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function updateStatus($id, $status) {
        $query = "UPDATE " . $this->table_name . " 
                  SET status = :status 
                  WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':id', $id);
        
        return $stmt->execute();
    }

    public function update($id, $data) {
        $query = "UPDATE " . $this->table_name . " 
                  SET judul = :judul, isi = :isi, lokasi = :lokasi, kategori_id = :kategori_id 
                  WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':judul', $data['judul']);
        $stmt->bindParam(':isi', $data['isi']);
        $stmt->bindParam(':lokasi', $data['lokasi']);
        $stmt->bindParam(':kategori_id', $data['kategori_id']);
        $stmt->bindParam(':id', $id);
        
        return $stmt->execute();
    }

    public function delete($id) {
        // Get foto before delete
        $aduan = $this->getById($id);
        
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        
        if ($stmt->execute()) {
            // Delete foto if exists
            if ($aduan && $aduan['foto']) {
                deleteFile($aduan['foto']);
            }
            return true;
        }
        return false;
    }

    public function getTotalByStatus($status = null) {
        if ($status) {
            $query = "SELECT COUNT(*) as total FROM " . $this->table_name . " WHERE status = :status";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':status', $status);
        } else {
            $query = "SELECT COUNT(*) as total FROM " . $this->table_name;
            $stmt = $this->conn->prepare($query);
        }
        
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total'];
    }

    public function getStatsByKategori() {
        $query = "SELECT k.nama_kategori, COUNT(a.id) as jumlah 
                  FROM kategori k
                  LEFT JOIN " . $this->table_name . " a ON k.id = a.kategori_id
                  GROUP BY k.id, k.nama_kategori
                  ORDER BY jumlah DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getMonthlyStats($year = null) {
        if (!$year) {
            $year = date('Y');
        }
        
        $query = "SELECT MONTH(created_at) as bulan, COUNT(*) as jumlah 
                  FROM " . $this->table_name . " 
                  WHERE YEAR(created_at) = :year
                  GROUP BY MONTH(created_at)
                  ORDER BY MONTH(created_at)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':year', $year);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getTodayStats() {
        $query = "SELECT COUNT(*) as total FROM " . $this->table_name . " 
                  WHERE DATE(created_at) = CURDATE()";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total'];
    }
}

?>
