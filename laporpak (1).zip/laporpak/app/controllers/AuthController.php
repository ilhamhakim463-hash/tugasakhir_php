<?php

require_once __DIR__ . '/../models/User.php';

class AuthController {
    private $db;
    private $userModel;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->userModel = new User($this->db);
    }

    public function showLogin() {
        Auth::requireGuest();
        include __DIR__ . '/../../views/auth/login.php';
    }

    public function showRegister() {
        Auth::requireGuest();
        include __DIR__ . '/../../views/auth/register.php';
    }

    public function login() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ' . BASE_URL . '?page=login');
            exit;
        }

        if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
            $_SESSION['error'] = 'Invalid CSRF token';
            header('Location: ' . BASE_URL . '?page=login');
            exit;
        }

        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($email) || empty($password)) {
            $_SESSION['error'] = 'Email dan password harus diisi';
            header('Location: ' . BASE_URL . '?page=login');
            exit;
        }

        $user = $this->userModel->login($email, $password);

        if ($user) {
            Auth::login($user);
            
            if ($user['role'] === ROLE_ADMIN) {
                header('Location: ' . BASE_URL . '?page=admin-dashboard');
            } else {
                header('Location: ' . BASE_URL . '?page=user-dashboard');
            }
            exit;
        } else {
            $_SESSION['error'] = 'Email atau password salah';
            header('Location: ' . BASE_URL . '?page=login');
            exit;
        }
    }

    public function register() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ' . BASE_URL . '?page=register');
            exit;
        }

        if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
            $_SESSION['error'] = 'Invalid CSRF token';
            header('Location: ' . BASE_URL . '?page=register');
            exit;
        }

        $nama = trim($_POST['nama'] ?? '');
        $nik = trim($_POST['nik'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        // Validasi
        if (empty($nama) || empty($nik) || empty($email) || empty($password)) {
            $_SESSION['error'] = 'Semua field harus diisi';
            header('Location: ' . BASE_URL . '?page=register');
            exit;
        }

        if (strlen($nik) !== 16) {
            $_SESSION['error'] = 'NIK harus 16 digit';
            header('Location: ' . BASE_URL . '?page=register');
            exit;
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['error'] = 'Format email tidak valid';
            header('Location: ' . BASE_URL . '?page=register');
            exit;
        }

        if (strlen($password) < 6) {
            $_SESSION['error'] = 'Password minimal 6 karakter';
            header('Location: ' . BASE_URL . '?page=register');
            exit;
        }

        if ($password !== $confirm_password) {
            $_SESSION['error'] = 'Password tidak sama';
            header('Location: ' . BASE_URL . '?page=register');
            exit;
        }

        if ($this->userModel->checkEmailExists($email)) {
            $_SESSION['error'] = 'Email sudah terdaftar';
            header('Location: ' . BASE_URL . '?page=register');
            exit;
        }

        if ($this->userModel->checkNIKExists($nik)) {
            $_SESSION['error'] = 'NIK sudah terdaftar';
            header('Location: ' . BASE_URL . '?page=register');
            exit;
        }

        $data = [
            'nama' => $nama,
            'nik' => $nik,
            'email' => $email,
            'password' => $password,
            'role' => ROLE_USER
        ];

        if ($this->userModel->register($data)) {
            $_SESSION['success'] = 'Registrasi berhasil! Silakan login';
            header('Location: ' . BASE_URL . '?page=login');
            exit;
        } else {
            $_SESSION['error'] = 'Registrasi gagal. Silakan coba lagi';
            header('Location: ' . BASE_URL . '?page=register');
            exit;
        }
    }

    public function logout() {
        Auth::logout();
        header('Location: ' . BASE_URL . '?page=login');
        exit;
    }
}

?>
