<?php

require_once __DIR__ . '/../models/Aduan.php';
require_once __DIR__ . '/../models/Kategori.php';
require_once __DIR__ . '/../models/Tanggapan.php';

class AduanController {
    private $db;
    private $aduanModel;
    private $kategoriModel;
    private $tanggapanModel;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->aduanModel = new Aduan($this->db);
        $this->kategoriModel = new Kategori($this->db);
        $this->tanggapanModel = new Tanggapan($this->db);
    }

    public function dashboard() {
        Auth::requireRole(ROLE_USER);
        
        $user = Auth::user();
        $aduan_list = $this->aduanModel->getByUserId($user['id']);
        
        $stats = [
            'total' => count($aduan_list),
            'pending' => count(array_filter($aduan_list, fn($a) => $a['status'] === STATUS_PENDING)),
            'proses' => count(array_filter($aduan_list, fn($a) => $a['status'] === STATUS_PROSES)),
            'selesai' => count(array_filter($aduan_list, fn($a) => $a['status'] === STATUS_SELESAI))
        ];
        
        include __DIR__ . '/../../views/user/dashboard.php';
    }

    public function create() {
        Auth::requireRole(ROLE_USER);
        
        $kategori_list = $this->kategoriModel->getAll();
        include __DIR__ . '/../../views/user/create.php';
    }

    public function store() {
        Auth::requireRole(ROLE_USER);
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ' . BASE_URL . '?page=user-create');
            exit;
        }

        if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
            $_SESSION['error'] = 'Invalid CSRF token';
            header('Location: ' . BASE_URL . '?page=user-create');
            exit;
        }

        $user = Auth::user();
        $judul = trim($_POST['judul'] ?? '');
        $isi = trim($_POST['isi'] ?? '');
        $lokasi = trim($_POST['lokasi'] ?? '');
        $kategori_id = $_POST['kategori_id'] ?? '';

        if (empty($judul) || empty($isi) || empty($kategori_id)) {
            $_SESSION['error'] = 'Judul, isi, dan kategori harus diisi';
            header('Location: ' . BASE_URL . '?page=user-create');
            exit;
        }

        $foto = null;
        if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
            $uploadResult = uploadFile($_FILES['foto']);
            if ($uploadResult['success']) {
                $foto = $uploadResult['filename'];
            } else {
                $_SESSION['error'] = $uploadResult['message'];
                header('Location: ' . BASE_URL . '?page=user-create');
                exit;
            }
        }

        $data = [
            'user_id' => $user['id'],
            'kategori_id' => $kategori_id,
            'judul' => $judul,
            'isi' => $isi,
            'lokasi' => $lokasi,
            'foto' => $foto,
            'status' => STATUS_PENDING
        ];

        if ($this->aduanModel->create($data)) {
            $_SESSION['success'] = 'Aduan berhasil dikirim';
            header('Location: ' . BASE_URL . '?page=user-dashboard');
            exit;
        } else {
            $_SESSION['error'] = 'Gagal mengirim aduan';
            header('Location: ' . BASE_URL . '?page=user-create');
            exit;
        }
    }

    public function detail() {
        Auth::requireRole(ROLE_USER);
        
        $id = $_GET['id'] ?? 0;
        $user = Auth::user();
        
        $aduan = $this->aduanModel->getById($id);
        
        if (!$aduan || $aduan['user_id'] != $user['id']) {
            $_SESSION['error'] = 'Aduan tidak ditemukan';
            header('Location: ' . BASE_URL . '?page=user-dashboard');
            exit;
        }
        
        $tanggapan_list = $this->tanggapanModel->getByAduanId($id);
        
        include __DIR__ . '/../../views/user/detail.php';
    }

    public function riwayat() {
        Auth::requireRole(ROLE_USER);
        
        $user = Auth::user();
        $aduan_list = $this->aduanModel->getByUserId($user['id']);
        
        include __DIR__ . '/../../views/user/riwayat.php';
    }
}

?>
