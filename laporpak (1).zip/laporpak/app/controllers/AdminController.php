<?php

require_once __DIR__ . '/../models/Aduan.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Kategori.php';
require_once __DIR__ . '/../models/Tanggapan.php';

class AdminController {
    private $db;
    private $aduanModel;
    private $userModel;
    private $kategoriModel;
    private $tanggapanModel;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->aduanModel = new Aduan($this->db);
        $this->userModel = new User($this->db);
        $this->kategoriModel = new Kategori($this->db);
        $this->tanggapanModel = new Tanggapan($this->db);
    }

    public function dashboard() {
        Auth::requireRole(ROLE_ADMIN);
        
        $stats = [
            'total' => $this->aduanModel->getTotalByStatus(),
            'pending' => $this->aduanModel->getTotalByStatus(STATUS_PENDING),
            'proses' => $this->aduanModel->getTotalByStatus(STATUS_PROSES),
            'selesai' => $this->aduanModel->getTotalByStatus(STATUS_SELESAI),
            'hari_ini' => $this->aduanModel->getTodayStats(),
            'total_user' => $this->userModel->getTotalUsers()
        ];
        
        $aduan_terbaru = $this->aduanModel->getAll(5);
        $stats_kategori = $this->aduanModel->getStatsByKategori();
        $stats_bulanan = $this->aduanModel->getMonthlyStats();
        
        include __DIR__ . '/../../views/admin/dashboard.php';
    }

    public function aduan() {
        Auth::requireRole(ROLE_ADMIN);
        
        $aduan_list = $this->aduanModel->getAll();
        include __DIR__ . '/../../views/admin/aduan.php';
    }

    public function aduanDetail() {
        Auth::requireRole(ROLE_ADMIN);
        
        $id = $_GET['id'] ?? 0;
        $aduan = $this->aduanModel->getById($id);
        
        if (!$aduan) {
            $_SESSION['error'] = 'Aduan tidak ditemukan';
            header('Location: ' . BASE_URL . '?page=admin-aduan');
            exit;
        }
        
        $tanggapan_list = $this->tanggapanModel->getByAduanId($id);
        $kategori_list = $this->kategoriModel->getAll();
        
        include __DIR__ . '/../../views/admin/aduan-detail.php';
    }

    public function updateStatus() {
        Auth::requireRole(ROLE_ADMIN);
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ' . BASE_URL . '?page=admin-aduan');
            exit;
        }

        if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
            $_SESSION['error'] = 'Invalid CSRF token';
            header('Location: ' . BASE_URL . '?page=admin-aduan');
            exit;
        }

        $id = $_POST['id'] ?? 0;
        $status = $_POST['status'] ?? '';

        if ($this->aduanModel->updateStatus($id, $status)) {
            $_SESSION['success'] = 'Status aduan berhasil diupdate';
        } else {
            $_SESSION['error'] = 'Gagal update status';
        }

        header('Location: ' . BASE_URL . '?page=admin-aduan-detail&id=' . $id);
        exit;
    }

    public function tanggapi() {
        Auth::requireRole(ROLE_ADMIN);
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ' . BASE_URL . '?page=admin-aduan');
            exit;
        }

        if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
            $_SESSION['error'] = 'Invalid CSRF token';
            header('Location: ' . BASE_URL . '?page=admin-aduan');
            exit;
        }

        $aduan_id = $_POST['aduan_id'] ?? 0;
        $isi = trim($_POST['isi'] ?? '');
        $user = Auth::user();

        if (empty($isi)) {
            $_SESSION['error'] = 'Tanggapan tidak boleh kosong';
            header('Location: ' . BASE_URL . '?page=admin-aduan-detail&id=' . $aduan_id);
            exit;
        }

        $data = [
            'aduan_id' => $aduan_id,
            'admin_id' => $user['id'],
            'isi' => $isi
        ];

        if ($this->tanggapanModel->create($data)) {
            $_SESSION['success'] = 'Tanggapan berhasil dikirim';
        } else {
            $_SESSION['error'] = 'Gagal mengirim tanggapan';
        }

        header('Location: ' . BASE_URL . '?page=admin-aduan-detail&id=' . $aduan_id);
        exit;
    }

    public function kategori() {
        Auth::requireRole(ROLE_ADMIN);
        
        $kategori_list = $this->kategoriModel->getAll();
        include __DIR__ . '/../../views/admin/kategori.php';
    }

    public function users() {
        Auth::requireRole(ROLE_ADMIN);
        
        $user_list = $this->userModel->getAll();
        include __DIR__ . '/../../views/admin/users.php';
    }
}

?>
