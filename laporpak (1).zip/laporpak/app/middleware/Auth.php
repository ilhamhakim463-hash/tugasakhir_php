<?php

class Auth {
    public static function check() {
        return isset($_SESSION['user_id']);
    }

    public static function user() {
        if (self::check()) {
            return [
                'id' => $_SESSION['user_id'],
                'nama' => $_SESSION['user_nama'],
                'email' => $_SESSION['user_email'],
                'role' => $_SESSION['user_role']
            ];
        }
        return null;
    }

    public static function login($user) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_nama'] = $user['nama'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_role'] = $user['role'];
        
        // Log aktivitas
        self::logActivity($user['id'], 'Login ke sistem');
    }

    public static function logout() {
        $user_id = $_SESSION['user_id'] ?? null;
        if ($user_id) {
            self::logActivity($user_id, 'Logout dari sistem');
        }
        
        session_unset();
        session_destroy();
    }

    public static function requireAuth() {
        if (!self::check()) {
            header('Location: ' . BASE_URL . '?page=login');
            exit;
        }
    }

    public static function requireGuest() {
        if (self::check()) {
            if ($_SESSION['user_role'] === ROLE_ADMIN) {
                header('Location: ' . BASE_URL . '?page=admin-dashboard');
            } else {
                header('Location: ' . BASE_URL . '?page=user-dashboard');
            }
            exit;
        }
    }

    public static function requireRole($role) {
        self::requireAuth();
        if ($_SESSION['user_role'] !== $role) {
            header('Location: ' . BASE_URL . '?page=unauthorized');
            exit;
        }
    }

    private static function logActivity($user_id, $aktivitas) {
        try {
            $database = new Database();
            $db = $database->getConnection();
            
            $query = "INSERT INTO logs (user_id, aktivitas, ip_address) VALUES (:user_id, :aktivitas, :ip)";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindParam(':aktivitas', $aktivitas);
            $ip = $_SERVER['REMOTE_ADDR'];
            $stmt->bindParam(':ip', $ip);
            $stmt->execute();
        } catch(PDOException $e) {
            // Silent fail untuk logging
        }
    }
}

?>
