<?php
session_start();

// Load configuration
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';

// Load helpers
require_once __DIR__ . '/../app/helpers/csrf.php';
require_once __DIR__ . '/../app/helpers/upload.php';

// Load middleware
require_once __DIR__ . '/../app/middleware/Auth.php';

// Load controllers
require_once __DIR__ . '/../app/controllers/AuthController.php';
require_once __DIR__ . '/../app/controllers/AduanController.php';
require_once __DIR__ . '/../app/controllers/AdminController.php';

// Routing
$page = $_GET['page'] ?? 'home';

// Initialize controllers
$authController = new AuthController();
$aduanController = new AduanController();
$adminController = new AdminController();

switch ($page) {
    // Public pages
    case 'home':
        if (Auth::check()) {
            if ($_SESSION['user_role'] === ROLE_ADMIN) {
                header('Location: ' . BASE_URL . '?page=admin-dashboard');
            } else {
                header('Location: ' . BASE_URL . '?page=user-dashboard');
            }
            exit;
        }
        include __DIR__ . '/../views/home.php';
        break;

    // Auth routes
    case 'login':
        $authController->showLogin();
        break;
    case 'login-process':
        $authController->login();
        break;
    case 'register':
        $authController->showRegister();
        break;
    case 'register-process':
        $authController->register();
        break;
    case 'logout':
        $authController->logout();
        break;

    // User routes
    case 'user-dashboard':
        $aduanController->dashboard();
        break;
    case 'user-create':
        $aduanController->create();
        break;
    case 'user-store':
        $aduanController->store();
        break;
    case 'user-detail':
        $aduanController->detail();
        break;
    case 'user-riwayat':
        $aduanController->riwayat();
        break;

    // Admin routes
    case 'admin-dashboard':
        $adminController->dashboard();
        break;
    case 'admin-aduan':
        $adminController->aduan();
        break;
    case 'admin-aduan-detail':
        $adminController->aduanDetail();
        break;
    case 'admin-update-status':
        $adminController->updateStatus();
        break;
    case 'admin-tanggapi':
        $adminController->tanggapi();
        break;
    case 'admin-kategori':
        $adminController->kategori();
        break;
    case 'admin-users':
        $adminController->users();
        break;

    // Error pages
    case 'unauthorized':
        include __DIR__ . '/../views/errors/unauthorized.php';
        break;
    
    default:
        include __DIR__ . '/../views/errors/404.php';
        break;
}
?>
