# 🏛️ LAPORPAK - Aplikasi Aduan Masyarakat

Aplikasi Aduan Masyarakat ke Pemerintah berbasis PHP murni dengan fitur lengkap untuk transparansi dan akuntabilitas.

## 📋 Fitur Utama

### User (Masyarakat)
- ✅ Registrasi & Login
- ✅ Kirim aduan dengan upload foto
- ✅ Lihat status aduan real-time
- ✅ Lihat tanggapan dari pemerintah
- ✅ Riwayat laporan lengkap
- ✅ Dashboard dengan statistik

### Admin (Pemerintah)
- ✅ Dashboard analytics dengan grafik
- ✅ Kelola semua aduan
- ✅ Verifikasi & update status aduan
- ✅ Balas aduan masyarakat
- ✅ Kelola kategori aduan
- ✅ Kelola users
- ✅ Statistik & laporan
- ✅ Log aktivitas

## 🛠️ Teknologi

- **Backend**: PHP 8.x (PDO)
- **Database**: MySQL / MariaDB (Port 3307)
- **Frontend**: Bootstrap 5, Chart.js
- **Server**: Apache (XAMPP / Laragon)

## 📦 Instalasi

### 1. Persiapan

Pastikan Anda sudah install:
- XAMPP atau Laragon
- MySQL/MariaDB berjalan di port **3307**
- PHP 8.x atau lebih tinggi

### 2. Extract File

Extract file `laporpak.zip` ke folder:
- XAMPP: `C:\xampp\htdocs\`
- Laragon: `C:\laragon\www\`

### 3. Import Database

1. Buka phpMyAdmin: `http://localhost/phpmyadmin`
2. Klik tab "SQL"
3. Copy & paste isi file `database.sql`
4. Klik "Go" untuk execute

**ATAU** import via command line:
```bash
mysql -u root -P 3307 < database.sql
```

### 4. Konfigurasi Database

Edit file `config/database.php` jika perlu mengubah kredensial database:

```php
private $host = "localhost:3307";  // Port 3307
private $db_name = "laporpak_db";
private $username = "root";
private $password = "";            // Sesuaikan jika ada password
```

### 5. Set Permissions

Buat folder `storage/uploads/` dan berikan write permission:

```bash
mkdir -p storage/uploads
chmod 777 storage/uploads
```

Di Windows, pastikan folder `storage/uploads/` bisa ditulis oleh web server.

### 6. Akses Aplikasi

Buka browser dan akses:
```
http://localhost/laporpak/public/
```

## 👤 Default Login

### Admin
- Email: `admin@laporpak.com`
- Password: `password`

### User
- Email: `user@laporpak.com`
- Password: `password`

## 📁 Struktur Folder

```
laporpak/
├── app/
│   ├── controllers/       # Logic aplikasi
│   ├── models/           # Database models
│   ├── middleware/       # Auth & security
│   └── helpers/          # Helper functions
├── config/               # Konfigurasi
├── public/               # Public files
│   └── index.php        # Entry point
├── views/                # Template HTML
│   ├── auth/            # Login & register
│   ├── user/            # User views
│   ├── admin/           # Admin views
│   └── errors/          # Error pages
├── storage/
│   └── uploads/         # Upload files
└── database.sql         # SQL schema
```

## 🔒 Keamanan

- ✅ Password hashing dengan `password_hash()`
- ✅ CSRF Token protection
- ✅ Prepared Statements (PDO)
- ✅ File upload validation
- ✅ Session security
- ✅ Role-based access control
- ✅ Input sanitization

## 🎨 Fitur Tambahan

- 📊 Dashboard dengan Chart.js
- 📸 Upload foto aduan (max 5MB)
- 🏷️ Kategori aduan yang fleksibel
- 📅 Timeline aduan
- 💬 Sistem tanggapan/komentar
- 📝 Log aktivitas
- 🔔 Status tracking real-time

## 🚀 Cara Penggunaan

### Sebagai User (Masyarakat)

1. **Register** - Buat akun dengan NIK 16 digit
2. **Login** - Masuk ke sistem
3. **Buat Aduan** - Klik "Buat Aduan Baru"
4. **Upload Foto** - Tambahkan bukti foto (opsional)
5. **Pantau Status** - Lihat progress di dashboard
6. **Lihat Tanggapan** - Baca balasan dari pemerintah

### Sebagai Admin (Pemerintah)

1. **Login** - Masuk sebagai admin
2. **Dashboard** - Lihat statistik & grafik
3. **Kelola Aduan** - Verifikasi dan proses aduan
4. **Update Status** - Ubah status: Pending → Proses → Selesai
5. **Beri Tanggapan** - Balas aduan masyarakat
6. **Monitoring** - Pantau aktivitas user

## 🐛 Troubleshooting

### Database Connection Error
- Pastikan MySQL berjalan di port 3307
- Cek kredensial di `config/database.php`
- Pastikan database `laporpak_db` sudah dibuat

### Upload Error
- Pastikan folder `storage/uploads/` ada dan writable
- Cek permission folder (777 di Linux/Mac)
- Maksimal ukuran file 5MB

### 404 Error
- Pastikan mod_rewrite aktif di Apache
- Cek file `.htaccess` ada di folder `public/`
- URL: `http://localhost/laporpak/public/`

## 📞 Support

Jika ada pertanyaan atau masalah, silakan buat issue atau hubungi developer.

## 📄 License

MIT License - Free to use for educational and commercial purposes.

---

**Dibuat dengan ❤️ untuk transparansi pemerintahan yang lebih baik**
