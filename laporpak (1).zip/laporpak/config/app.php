<?php

define('BASE_URL', 'http://localhost/laporpak/public/');
define('APP_NAME', 'LAPORPAK');
define('UPLOAD_PATH', __DIR__ . '/../storage/uploads/');
define('UPLOAD_URL', BASE_URL . 'storage/uploads/');

// Status aduan
define('STATUS_PENDING', 'pending');
define('STATUS_PROSES', 'proses');
define('STATUS_SELESAI', 'selesai');
define('STATUS_DITOLAK', 'ditolak');

// Role
define('ROLE_USER', 'user');
define('ROLE_ADMIN', 'admin');

// Session config
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 0); // set to 1 if using HTTPS

?>
